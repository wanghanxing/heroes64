export const NAME_TITILE = ['welfare', 'day', 'android', 'ios', 'web'];
