/**
 * Created by yi on 2017-01-06.
 */
export const incrementCounter = function ({ dispatch, state }) {

};
